import React, { useState } from 'react';
import './App.css';
import Sidebar from './components/SideBar';
import StatsBar from './components/StatsBar';
import CycleCalendar from './components/CycleCalendar';
import SymptomLogger from './components/SymptomLogger';
import InsightPanel from './components/InsightPanel';

function App() {
  // This holds all the entries the user logs
  const [entries, setEntries] = useState([
    { date: '2026-04-22', symptoms: ['Bloating'] },
    { date: '2026-04-23', symptoms: ['Heavy flow'] },
    { date: '2026-04-24', symptoms: ['Cramps', 'Fatigue'] },
  ]);

  // Called when user saves a new symptom entry
  const handleSaveEntry = (newEntry) => {
    setEntries((prev) => [newEntry, ...prev]);
  };

  return (
    <div className="app-shell">
      <Sidebar />

      <main className="main-content">
        <div className="top-bar">
          <div>
            <h1 className="greeting">Good morning, Priya</h1>
            <p className="subtext">Saturday, April 25 · Day 3 of cycle</p>
          </div>
        </div>

        <StatsBar />
        <CycleCalendar />
        <SymptomLogger onSave={handleSaveEntry} />
      </main>

      <InsightPanel entries={entries} />
    </div>
  );
}

export default App;