import React from 'react';

// The four summary numbers shown at the top of the dashboard
const STATS = [
  { label: 'Cycle length',  value: '28', unit: 'days', sub: 'Avg: 28 days', color: 'pink' },
  { label: 'Period length', value: '5',  unit: 'days', sub: 'Avg: 5 days',  color: ''     },
  { label: 'Next period',   value: '25', unit: 'days', sub: 'May 20',       color: ''     },
  { label: 'Fertile window',value: '11', unit: 'days', sub: 'May 5–10',     color: 'teal' },
];

function StatsBar() {
  return (
    <div className="stats-bar">
      {STATS.map((s) => (
        <div key={s.label} className="stat-card">
          <div className="stat-card-label">{s.label}</div>
          <div className={`stat-card-value ${s.color}`}>
            {s.value}{' '}
            <span style={{ fontSize: 13, fontFamily: "'DM Sans', sans-serif" }}>
              {s.unit}
            </span>
          </div>
          <div className="stat-card-sub">{s.sub}</div>
        </div>
      ))}
    </div>
  );
}

export default StatsBar;