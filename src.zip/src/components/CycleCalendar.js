import React from 'react';

const WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

// April 2026 starts on a Wednesday (index 3), so we need 3 empty slots first
const EMPTY_SLOTS = 3;
const TOTAL_DAYS  = 30;

// Define what "type" each date is so we can colour it correctly
function getDayType(day) {
  if (day === 25)              return 'today';     // today
  if (day >= 23 && day <= 30) return 'period';    // period days (prev cycle bleed mapped to Apr)
  if (day >= 1  && day <= 8)  return 'period';    // current period (days 1-8 of April)
  if (day === 19)              return 'ovulation'; // ovulation day
  if (day >= 14 && day <= 24) return 'fertile';   // fertile window
  return '';
}

function CycleCalendar() {
  return (
    <div className="calendar-card">

      {/* Header row */}
      <div className="calendar-header">
        <span className="section-title">April 2026</span>
        <div className="legend">
          <span className="pill pill-pink">Menstrual</span>
          <span className="pill pill-teal">Fertile</span>
          <span className="pill pill-green">Ovulation</span>
        </div>
      </div>

      {/* Calendar grid */}
      <div className="cal-grid">

        {/* Day-of-week headers */}
        {WEEKDAYS.map((d) => (
          <div key={d} className="cal-weekday">{d}</div>
        ))}

        {/* Empty slots before the 1st */}
        {Array.from({ length: EMPTY_SLOTS }).map((_, i) => (
          <div key={`empty-${i}`} className="cal-day empty" />
        ))}

        {/* Actual days */}
        {Array.from({ length: TOTAL_DAYS }, (_, i) => i + 1).map((day) => {
          const type = getDayType(day);
          return (
            <div key={day} className={`cal-day ${type}`}>
              {day}
            </div>
          );
        })}

      </div>
    </div>
  );
}

export default CycleCalendar;