import React, { useState } from 'react';

// Each item in the sidebar navigation
const NAV_ITEMS = [
  { label: 'Dashboard' },
  { label: 'Cycle Log' },
  { label: 'Insights' },
  { label: 'Symptoms' },
  { label: 'Profile' },
];

function Sidebar() {
  const [activeItem, setActiveItem] = useState('Dashboard');

  return (
    <aside className="sidebar">

      {/* Logo */}
      <div className="sidebar-logo">
        <span style={{ fontSize: 18 }}>🌸</span>
        <span className="sidebar-logo-text">Period Care</span>
      </div>

      {/* Navigation links */}
      {NAV_ITEMS.map((item) => (
        <button
          key={item.label}
          type="button"
          className={`nav-item ${item.label === activeItem ? 'active' : ''}`}
          onClick={() => setActiveItem(item.label)}
        >
          {item.label}
        </button>
      ))}

      {/* Current phase widget at the bottom */}
      <div className="phase-widget">
        <div className="phase-label">Current phase</div>
        <div className="phase-name">
          <div className="phase-dot" />
          Menstrual
        </div>
        <div className="phase-progress-row">
          <span>Day 3</span>
          <span>28 days</span>
        </div>
        <div className="phase-track">
          <div className="phase-fill" />
        </div>
      </div>

    </aside>
  );
}

export default Sidebar;