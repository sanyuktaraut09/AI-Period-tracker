import React, { useState, useEffect } from 'react';

const PHASES = [
  { name: 'Menstrual',  days: '1–5',   color: '#d4537e', width: '18%' },
  { name: 'Follicular', days: '6–13',  color: '#fac775', width: '29%' },
  { name: 'Ovulation',  days: '14',    color: '#1d9e75', width: '4%'  },
  { name: 'Luteal',     days: '15–28', color: '#afa9ec', width: '50%' },
];

function InsightPanel({ entries }) {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);

  useEffect(() => {
    if (entries.length === 0) return;
    const latestSymptoms = entries[0].symptoms;
    if (latestSymptoms.length === 0) return;
    const query = latestSymptoms.join(' ');
    fetchRecommendations(query);
  }, [entries]);

  async function fetchRecommendations(query) {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `http://localhost:8000/recommend?query=${encodeURIComponent(query)}`
      );
      if (!response.ok) throw new Error('Backend returned an error');
      const data = await response.json();
      setArticles(data.results);
    } catch (err) {
      setError('Could not reach backend. Is it running?');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  function formatDate(dateStr) {
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  return (
    <aside className="insight-panel">
      <div className="section-title">AI Insights</div>

      <div>
        <div className="panel-section-label">Recommended for you</div>
        {loading && (
          <div style={{ fontSize: 12, color: '#888780', padding: '8px 0' }}>
            Finding articles...
          </div>
        )}
        {error && (
          <div style={{ fontSize: 12, color: '#993556', background: '#fbeaf0', padding: '8px 10px', borderRadius: 8, marginBottom: 8 }}>
            {error}
          </div>
        )}
        {!loading && !error && articles.length === 0 && (
          <div style={{ fontSize: 12, color: '#888780', padding: '8px 0' }}>
            Log symptoms to get personalised article recommendations.
          </div>
        )}
        {articles.map((article, i) => (
          <div key={i} className="insight-card" style={{ marginBottom: 8 }}>
            <div className="insight-meta">
              <span style={{ fontSize: 14 }}>🧠</span>
              <span className="insight-meta-label">AI pick</span>
            </div>
            <div style={{ fontWeight: 500, fontSize: 12, marginBottom: 4 }}>{article.title}</div>
            <p className="insight-body">{article.content}</p>
          </div>
        ))}
      </div>

      <div className="insight-card">
        <div className="insight-meta">
          <span style={{ fontSize: 14 }}>📅</span>
          <span className="insight-meta-label">Upcoming</span>
        </div>
        <div style={{ fontSize: 12, color: '#888780', marginBottom: 4 }}>Fertile window in</div>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 20, color: '#1d9e75' }}>10 days</div>
        <div style={{ fontSize: 11, color: '#888780', marginTop: 2 }}>May 5 – May 10</div>
      </div>

      <div>
        <div className="panel-section-label">Cycle phases</div>
        <div className="phase-bars">
          {PHASES.map((p) => (
            <div key={p.name} className="phase-bar-row">
              <div className="phase-bar-labels">
                <span>{p.name}</span>
                <span style={{ color: '#888780' }}>{p.days}</span>
              </div>
              <div className="phase-bar-track">
                <div className="phase-bar-fill" style={{ background: p.color, width: p.width }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="panel-section-label">Recent entries</div>
        {entries.length === 0 && (
          <div style={{ fontSize: 12, color: '#888780' }}>No entries yet.</div>
        )}
        {entries.slice(0, 5).map((entry, i) => (
          <div key={i} className="entry-row">
            <span>{formatDate(entry.date)}</span>
            <span className="pill pill-pink">
              {entry.symptoms.join(', ') || entry.note || '—'}
            </span>
          </div>
        ))}
      </div>

      <button className="btn-summary">AI health summary →</button>
    </aside>
  );
}

export default InsightPanel;