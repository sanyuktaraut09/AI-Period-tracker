import React, { useState, useCallback } from 'react';
import DashboardCard from './DashboardCard';

// All the symptom chips the user can tap
const ALL_SYMPTOMS = [
  { emoji: '😣', label: 'Cramps'      },
  { emoji: '😴', label: 'Fatigue'     },
  { emoji: '🫠', label: 'Bloating'    },
  { emoji: '😤', label: 'Mood swings' },
  { emoji: '🤕', label: 'Headache'    },
  { emoji: '🍫', label: 'Cravings'    },
  { emoji: '💧', label: 'Heavy flow'  },
  { emoji: '✨', label: 'Feeling good'},
];

// onSave is a function passed in from App.js so the parent can store the entry
function SymptomLogger({ onSave }) {
  const [selected, setSelected] = useState([]);  // which chips are tapped
  const [note, setNote]         = useState('');  // text from the input box
  const [aiResult, setAiResult] = useState(null);
  const [detectedSymptoms, setDetectedSymptoms] = useState([]);
  const [foods, setFoods] = useState([]);
  const [remedies, setRemedies] = useState([]);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState(null);

  // Toggle a chip on or off
  const toggleChip = useCallback((label) => {
    if (loading) return;
    setSelected((prev) =>
      prev.includes(label)
        ? prev.filter((s) => s !== label)   // remove if already selected
        : [...prev, label]                  // add if not selected
    );
  }, [loading]);

  // Save the entry and reset the form
  const handleSave = useCallback(() => {
    if (loading) return;
    if (selected.length === 0 && note.trim() === '') return; // nothing to save

    const today = new Date().toISOString().split('T')[0]; // "2026-04-25"

    onSave({
      date:     today,
      symptoms: selected,
      note:     note.trim(),
    });

    // Reset form
    setSelected([]);
    setNote('');
  }, [loading, note, onSave, selected]);

  const analyzeWithAI = useCallback(async () => {
    if (loading || note.trim() === '') return;
    setLoading(true);
    setError(null);
    setAiResult(null);

    try {
      const resp = await fetch('http://127.0.0.1:8000/api/symptoms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: note }),
      });
      if (!resp.ok) {
        const message = await resp.text();
        throw new Error(message || `Server error ${resp.status}`);
      }
      const data = await resp.json();
      console.log("Backend Response:", data);
      setAiResult(data);
      setDetectedSymptoms(data.detected_symptoms || []);
      console.log("Detected Symptoms State:", data.detected_symptoms);
      setFoods(data.recommended_foods || []);
      setRemedies(data.recommended_remedies || []);
      setArticles(data.related_articles || []);
    } catch (e) {
      console.error('AI analysis failed', e);
      setError(typeof e === 'string' ? e : e.message || 'Could not reach AI service. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [loading, note]);

  return (
    <div className="symptom-card">
      <div className="section-title" style={{ marginBottom: 14 }}>
        How are you feeling today?
      </div>

      {/* Symptom chips */}
      <div className="chips-wrap">
        {ALL_SYMPTOMS.map(({ emoji, label }) => (
          <button
            key={label}
            className={`chip ${selected.includes(label) ? 'selected' : ''}`}
            onClick={() => toggleChip(label)}
          >
            {emoji} {label}
          </button>
        ))}
      </div>

      {/* Note input + Save button */}
      <div className="log-row">
        <input
          className="log-input"
          type="text"
          placeholder="Add a note (optional)..."
          value={note}
          onChange={(e) => {
            setNote(e.target.value);
            if (error) setError(null);
          }}
        />
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className="btn-primary"
            type="button"
            onClick={handleSave}
            disabled={loading || (selected.length === 0 && note.trim() === '')}
          >
            Save
          </button>
          <button
            className="btn-secondary"
            type="button"
            onClick={analyzeWithAI}
            disabled={loading || note.trim() === ''}
          >
            {loading ? 'Analyzing...' : 'Analyze with AI'}
          </button>
        </div>
      </div>

      {/* AI Results Dashboard */}
      <div style={{ marginTop: 16 }}>
        <DashboardCard
          detectedSymptoms={detectedSymptoms}
          foods={foods}
          remedies={remedies}
          articles={articles}
          loading={loading}
          error={error}
        />
      </div>
    </div>
  );
}

export default SymptomLogger;